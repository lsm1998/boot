package com.lsm1998.springboot.servlet;

/**
 * @作者：刘时明
 * @时间：19-1-10-下午4:47
 * @说明：
 */
public interface BaseServlet
{
    void loadOnStartup();
}
