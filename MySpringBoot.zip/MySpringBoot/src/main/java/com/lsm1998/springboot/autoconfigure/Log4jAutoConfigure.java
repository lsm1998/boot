package com.lsm1998.springboot.autoconfigure;

/**
 * @作者：刘时明
 * @时间：19-1-14-下午5:07
 * @说明：
 */
public class Log4jAutoConfigure
{

}
