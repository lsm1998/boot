package com.lsm1998.spring.jdbc.datasource;

/**
 * @作者：刘时明
 * @时间:2018/12/23-21:42
 * @说明：数据源事务管理器
 */
public class MyDataSourceTransactionManager
{

}
