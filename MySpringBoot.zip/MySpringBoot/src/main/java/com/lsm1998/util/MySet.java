package com.lsm1998.util;

/**
 * @作者：刘时明
 * @时间:2018/12/23-0:57
 * @说明：Set集合顶层容器
 */
public interface MySet<E> extends MyCollection<E>,Iterable<E>
{

}
