package com.lsm1998.log4j.core;

/**
 * @作者：刘时明
 * @时间：19-1-11-上午10:24
 * @说明：
 */
public interface MyLogger
{
    void debug(String debug);

    void info(String info);

    void error(String error);
}
