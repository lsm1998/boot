package com.lsm1998.ibatis.annotation;

/**
 * @作者：刘时明
 * @时间：18-12-21-下午5:19
 * @说明：
 */
public @interface MyManyToOne
{
}
