package test.controller;

import com.lsm1998.spring.web.annotation.MyController;
import com.lsm1998.spring.web.annotation.MyRequestMapping;

/**
 * @作者：刘时明
 * @时间：2019/1/14-13:00
 * @说明：
 */
@MyController
@MyRequestMapping("order")
public class OrderController
{

}
